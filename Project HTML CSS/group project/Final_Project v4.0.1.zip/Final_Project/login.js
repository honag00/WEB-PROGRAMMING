console.log("Run successfully!");
document.addEventListener("DOMContentLoaded", () => {
    let createForm = document.getElementById("signup_button");
    let signinForm = document.getElementById("login_button");
    signinForm.addEventListener("click", (e) => {
        e.preventDefault();
        console.log("create form submitted");
        checking();
    });
    createForm.addEventListener("click", (e) => {
        e.preventDefault();
        let userName=document.getElementById("signup_username");
        let gmail = document.getElementById("signup_email");
        let pw1 = document.getElementById("signup_passwork1");
        let pw2 = document.getElementById("signup_passwork2");
        if(userName.value.length == 0){
            alert('Please fill in userName');
    
        }else if(pw1.value.length == 0){
            alert('Please fill in password');
    
        }else if(userName.value.length == 0 && pw1.value.length == 0){
            alert('Please fill in email and password');
    
        }else if(pw1.value !=pw2.value ){
            alert('Passworks does not match');
        }else if(gmail.value.length==0){
            alert('Please fill in email');
        }
        else{
            localStorage.setItem('userName', userName.value);
            localStorage.setItem('gmail', gmail.value);
            localStorage.setItem('pw1', pw1.value);
            alert('Your account has been created');
            window.location.href = "login.html";
        }
    });
    function checking(){
        var storedName = localStorage.getItem('userName');
        var storedPw = localStorage.getItem('pw1');
    
        var userName = document.getElementById('login_username');
        var userPw = document.getElementById('login_passwork');

        if(userName.value == storedName && userPw.value == storedPw){
            alert('You are logged in.');
            // loginDatabase(storedName,storedPw);
            localStorage.setItem('logindata-info', 'true');
            window.location.href = "index.html";
        }else{
            alert('Error on login');
            return;
        }
        
    }
    function login(val){
        let output="";
        output += `
        <li type="button" data-target="#">
            ${val.img} - ${val.user}
        </li>
        `
        document.querySelector("div#login-signup ul").innerHTML = output;
    }
    function loginDatabase(user, password){
        let newLogin = {
            user: user,
            password: password,
            img: `<img class="peguin" src="images/CanhCut.jpg" alt="">`
        }
        login(newLogin);
        
    }
    

});