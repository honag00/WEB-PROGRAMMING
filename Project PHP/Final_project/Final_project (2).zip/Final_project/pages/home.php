<?php 
    include 'includes/header.php';
?>

<div class="jumbotron">
    <div class="container">
        <h1 class="display-4">Title</h1>
        <p class="lead">Subtitle</p>
        <hr class="my-4">
        <p>Content</p>
    </div>
</div>

<?php 
    include "includes/loading.php"; 
    include 'includes/footer.php';
?>