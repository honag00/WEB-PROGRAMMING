<?php $conn = new PDO('mysql:host=localhost;dbname=2023_itec_blog', 'root', '');
