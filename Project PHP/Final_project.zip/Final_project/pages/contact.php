<?php
include 'includes/header.php';
?>
<iframe
    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.6317760522047!2d106.68071964539897!3d10.762835881134844!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752f1c06f4e1dd%3A0x43900f1d4539a3d!2sUniversity%20of%20Science%20-%20VNUHCM!5e0!3m2!1sen!2s!4v1686295900010!5m2!1sen!2s"
    width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"
    referrerpolicy="no-referrer-when-downgrade"></iframe>

<div class="jumbotron">
    <div class="container">
        <h1 class="display-4">Contact</h1>
        <p class="lead">Subtitle</p>
        <hr class="my-4">
        <p>Content</p>
    </div>
</div>

<?php
include 'includes/footer.php';
?>