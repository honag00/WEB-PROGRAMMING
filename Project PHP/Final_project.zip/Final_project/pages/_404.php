<?php include "includes/header.php";?>

    <div class="jumbotron">
        <div class="container">
        <h1 class="display-4">404 page not found</h1>
        <p class="lead">Only u and bé heo here</p>
        <hr class="my-4">
        <p><a href="<?php echo ROOT; ?>">Return home</a></p>
        </div>
    </div>

<?php include "includes/footer.php"; ?>